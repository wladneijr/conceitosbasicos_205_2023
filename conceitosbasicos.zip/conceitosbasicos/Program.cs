﻿// See https://aka.ms/new-console-template for more information
using System.Runtime.InteropServices;


Console.WriteLine("Minha altura em nano é " +altura+ " e meu peso é "+ peso +" e em nano é "+ nanoAltura + "nm");

int idad = 30;

Console.WriteLine("A idade de Marcos é "+ idad +"!");

double ida = 30.0;

Console.WriteLine("A idade de Marcos é "+ (int)ida +"!");

string parcela1 = "10";
string parcela2 = "20";

Console.WriteLine(parcela1+parcela2);
